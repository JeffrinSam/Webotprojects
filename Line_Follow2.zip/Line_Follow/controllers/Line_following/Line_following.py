from controller import Robot
robot = Robot()

timestep = int(robot.getBasicTimeStep())

gs = []
for i in range(3):
    gs.append(robot.getDevice("gs" + str(i)))
    gs[-1].enable(timestep)

print("Ready")

while robot.step(timestep) != -1:
    g = []

    # Había un error aquí, la función es getValue(), no getvalue
    for gsensor in gs:
        g.append(gsensor.getValue())
        
        
        
    if (g[0]>600 and g[1]<450 and g[2]>600):
        tr,tl=0,0
        phildot,phirdot=MAX_VELOCITY*0.25,MAX_VELOCITY*0.25
    elif (g[0]>600 and g[1]<450 and g[2]<450):    
        tr=1
        tl=0
    elif (g[0]<450 and g[1]<450 and g[2]>600):    
        tr=0
        tl=1
    elif (g[0]>600 and g[1]>600 and g[2]>600):    
        if (tr==1):
            phildot,phirdot=MAX_VELOCITY*0.25,-MAX_VELOCITY*0.25
        elif (tl==1):
            phildot,phirdot=-MAX_VELOCITY*0.25,MAX_VELOCITY*0.25
    elif (g[0]<300 and g[1]<300 and g[2]<300):    
        phildot,phirdot=-MAX_VELOCITY*0,MAX_VELOCITY*0
    print(g)