from controller import Robot
import math

MAX_VELOCITY = 6.24

robot = Robot()

timestep = int(robot.getBasicTimeStep())

gs = []

# Enable ground sensors
for i in range(3):
    gs.append(robot.getDevice("gs" + str(i)))
    gs[-1].enable(timestep)
    
# Initialize motor devices
leftMotor = robot.getDevice("left wheel motor")
rightMotor = robot.getDevice("right wheel motor")
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# Initialize variables
phildot, phirdot = 0, 0
dx = 0
w = 0
poss = [0, 0, 0]
xw = 0
yw = 0
dw = 0

# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    g = []
    
    # Read ground sensor values
    for gsensor in gs:
        g.append(gsensor.getValue())
    
    # Control logic based on ground sensor values
    if(g[0] < 400 and g[1] < 400):
        phirdot = 0.80 * MAX_VELOCITY * 0.25
        phildot = 0.80 * MAX_VELOCITY * -0.05
    elif(g[2] < 400 and g[1] < 400):
        phirdot = 0.80 * MAX_VELOCITY * -0.05
        phildot = 0.80 * MAX_VELOCITY * 0.25
    elif(g[1] < 400):
        phirdot = 0.80 * MAX_VELOCITY * 0.30
        phildot = 0.80 * MAX_VELOCITY * 0.30
    
    # Set motor velocities
    leftMotor.setVelocity(phildot)
    rightMotor.setVelocity(phirdot)
    
    # Calculate change in position and orientation
    dx = ((phildot * 0.0201 + phirdot * 0.0201)) * (32 / 1000) * (1 / 2)
    dw = ((-phildot * 0.0201 + phirdot * 0.0201)) * (32 / 1000) * (1 / 0.052) * (180 / math.pi)
    
    # Update orientation
    w += dw
    
    # Update position
    xw += math.cos(math.radians(w)) * dx
    yw += math.sin(math.radians(w)) * dx
    
    # Store current position and orientation
    poss = [xw, yw, w]
    
    # Print position and orientation
    print("xw, yw, w= ", poss)
    print("Error= ", math.sqrt(xw**2 + yw**2))
    pass