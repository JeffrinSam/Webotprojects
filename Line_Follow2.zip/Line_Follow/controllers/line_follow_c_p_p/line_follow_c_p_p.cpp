#include <webots/Robot.hpp>
#include <webots/DistanceSensor.hpp>
#include <iostream>
#include <vector>

using namespace webots;
using namespace std;

int main() {
    Robot robot;
    int timestep = (int)robot.getBasicTimeStep();

    vector<DistanceSensor*> gs;
    for (int i = 0; i < 3; ++i) {
        gs.push_back(robot.getDistanceSensor("gs" + to_string(i)));
        gs[i]->enable(timestep);
    }

    while (robot.step(timestep) != -1) {
        vector<double> g;
        for (auto gsensor : gs) {
            g.push_back(gsensor->getValue());
        }
        for (auto value : g) {
            cout << value << " ";
        }
        cout << endl;
    }

    return 0;
}