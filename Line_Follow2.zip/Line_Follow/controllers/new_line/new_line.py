"""line controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
MAX_VELOCITY=6.24

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

gs = []
for i in range(3):
    gs.append(robot.getDevice("gs" + str(i)))
    gs[-1].enable(timestep)
leftMotor = robot.getDevice("left wheel motor")
rightMotor = robot.getDevice("right wheel motor")
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)
phildot,phirdot=0,0
tr=0;
tl=0;
counter=0
velocityl=[0,0,0]
velocityr=[0,0,0]
dist=0
w=0;
# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    g = []
    
    for gsensor in gs:
        g.append(gsensor.getValue())
    print(g)
    if(g[0]<400 and g[1]<400):
        phirdot=MAX_VELOCITY*0.25
        phildot=MAX_VELOCITY*-0.05
    elif(g[2]<400 and g[1]<400):
        phirdot=MAX_VELOCITY*-0.05
        phildot=MAX_VELOCITY*0.25
    elif(g[1]<400):
        phirdot=MAX_VELOCITY*0.30
        phildot=MAX_VELOCITY*0.30
    
    leftMotor.setVelocity(phildot)
    rightMotor.setVelocity(phirdot)
    dist+=((phildot*0.0201+phirdot*0.0201))*(32/1000)*(1/2)
    w+=((phildot*0.0201-phirdot*0.0201))*(32/1000)*(1/0.052)*(180/3.1416)
    print(phirdot)
    print(dist)
    print(w)
    pass
