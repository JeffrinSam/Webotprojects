from controller import Robot
import numpy as np

# time in [ms] of a simulation step
TIME_STEP = 32

#---------------------------------------------------------------
# create the Robot instance.
robot = Robot()

# initialize devices
gs = []
for i in range(3):
    gs.append(robot.getDevice(f"gs{i}"))
    gs[i].enable(TIME_STEP)

leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)
#---------------------------------------------------------------


MAX_SPEED = 6.28
F_SPEED = 0.8* MAX_SPEED
TURN_M_SPEED = 0.4* MAX_SPEED
TURN_F_SPEED = -0.28* MAX_SPEED

phildot, phirdot = 0,0

r = 20.5 /1000
d = 52 / 1000
time_step = TIME_STEP / 1000

dist = 0

xw = 0
yw = 0.028

alpha = 1.5708

threshold = 550
# feedback loop: step simulation until receiving an exit event
while robot.step(TIME_STEP) != -1:
    # read sensors outputs
    g = []
    
    for i in range(3):
        g.append(gs[i].getValue())
    
    # print(g)
    if (g[0] > 500 and g[1] < 320 and g[2] > 500):
        # print("FORWARD",g)
        phildot, phirdot = F_SPEED, F_SPEED

    elif g[0] > threshold and g[2] < threshold:
        # print("RIGHT",g)
        phildot, phirdot = TURN_M_SPEED, TURN_F_SPEED
        
    elif g[0] < threshold and g[2] > threshold :
        # print("LEFT",g)
        phildot, phirdot = TURN_F_SPEED, TURN_M_SPEED
        
    elif (g[0] < 350 and g[1] < 350 and g[2] < 350 and  alpha/3.1415*180 < -300):
        print("COMPLETE")
        print(xw, yw , alpha/3.1415*180)
        print("Error",np.sqrt(xw**2+yw**2)) 
        phildot, phirdot = 0,0
        leftMotor.setVelocity(phildot)
        rightMotor.setVelocity(phirdot)
        break
    
    
    delta_x = (r*phildot/2 + r*phirdot/2) * time_step
    delta_omega = (r*phirdot* time_step - r*phildot* time_step) /(d*1)

    
    dist += delta_x
    alpha += delta_omega
    
    
    xw = xw + np.cos(alpha) * delta_x
    yw = yw + np.sin(alpha) * delta_x
    
    
    print(xw, yw , alpha/3.1415*180)
    
         
    leftMotor.setVelocity(phildot)
    rightMotor.setVelocity(phirdot)
    

  